import app from "./app";
import { logger } from "./lib/logger";

export default app;

if (!process.env["VERCEL"]) {
  const rawPort = process.env["PORT"];
  const port = rawPort ? Number(rawPort) : 3000;

  if (Number.isNaN(port) || port <= 0) {
    throw new Error(`Invalid PORT value: "${rawPort}"`);
  }

  app.listen(port, (err) => {
    if (err) {
      logger.error({ err }, "Error listening on port");
      process.exit(1);
    }

    logger.info({ port }, "Server listening");
  });
}
